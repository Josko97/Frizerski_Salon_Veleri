<template>
  <q-page class="q-pa-md" style="position: relative;">
    <!-- Gumb za prijavu u gornjem desnom kutu -->
    <q-btn label="Prijava" color="primary" @click="showLogin = true" class="absolute-top-right q-ma-md" />

    <!-- Modalni dijalog za prijavu / registraciju -->
    <q-dialog v-model="showLogin" persistent>
      <q-card style="min-width: 400px">
        <q-card-section>
          <div class="text-h6">{{ isRegistering ? 'Registracija' : 'Prijava' }}</div>
        </q-card-section>

        <q-card-section>
          <q-form @submit.prevent="isRegistering ? register() : login()">
            <q-input v-if="isRegistering" v-model="name" label="Ime" filled class="q-mb-sm" />
            <q-input v-model="username" label="Korisničko Ime" type="username" filled class="q-mb-sm" />
            <q-input v-model="password" label="Lozinka" type="password" filled class="q-mb-sm" />
            <q-btn type="submit" label="Pošalji" color="primary" class="full-width" />
          </q-form>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat @click="isRegistering = !isRegistering">
            {{ isRegistering ? 'Već imate račun? Prijavite se' : 'Nemate račun? Registrirajte se' }}
          </q-btn>
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const showLogin = ref(false)
const isRegistering = ref(false)

const name = ref('')
const username = ref('')
const password = ref('')

const login = async () => {
  try {
    const res = await axios.post('http://localhost:8080/api/public/auth/signin', {
      username: username.value,
      password: password.value
    })

    localStorage.setItem('jwt', res.data.token)
    showLogin.value = false
    console.log('Uspješna prijava')
  } catch (err) {
    console.error('Greška pri prijavi', err)
  }
}

const register = async () => {
  try {
    await axios.post('http://localhost:8080/api/public/auth/register', {
      name: name.value,
      username: username.value,
      password: password.value
    })
    isRegistering.value = false
    console.log('Uspješna registracija')
  } catch (err) {
    console.error('Greška pri registraciji', err)
  }
}
</script>
