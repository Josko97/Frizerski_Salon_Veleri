<template>
  <div class="q-pa-md" style="max-width: 400px; margin: auto">
    <q-form @submit="login">
      <q-input v-model="username" label="Username" type="username" required />
      <q-input v-model="password" label="Lozinka" type="password" required />
      <q-btn type="submit" label="Prijava" color="primary" class="q-mt-md" />
    </q-form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const username = ref('')
const password = ref('')

const login = async () => {
  try {
    const res = await axios.post('http://localhost:8080/api/public/auth/signin', {
      username: username.value,
      password: password.value
    }, {
      withCredentials: true // Ovo je ključno za cookie
    })
    localStorage.setItem('jwt', res.data.token)
    console.log('Uspješno prijavljen!')
  } catch (err) {
    console.error('Greška pri prijavi', err)
  }
}
</script>
