<template>
  <div class="q-pa-md" style="max-width: 400px; margin: auto">
    <q-form @submit="register">
      <q-input v-model="name" label="Ime" required />
      <q-input v-model="email" label="Email" type="email" required />
      <q-input v-model="password" label="Lozinka" type="password" required />
      <q-btn type="submit" label="Registracija" color="secondary" class="q-mt-md" />
    </q-form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const name = ref('')
const email = ref('')
const password = ref('')

const register = async () => {
  try {
    await axios.post('http://localhost:8080/api/public/registracija', {
      name: name.value,
      email: email.value,
      password: password.value
    })
    console.log('Uspješna registracija')
  } catch (err) {
    console.error('Greška pri registraciji', err)
  }
}
</script>
