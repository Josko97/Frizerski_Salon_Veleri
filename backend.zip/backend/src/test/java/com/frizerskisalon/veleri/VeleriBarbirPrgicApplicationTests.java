package com.frizerskisalon.veleri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeleriBarbirPrgicApplicationTests {

	@Test
	void contextLoads() {
	}

}
