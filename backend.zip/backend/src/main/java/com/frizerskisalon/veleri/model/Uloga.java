package com.frizerskisalon.veleri.model;

public enum Uloga {
	ROLE_KORISNIK, ROLE_FRIZER, ROLE_ADMIN
}
