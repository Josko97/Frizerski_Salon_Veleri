package com.frizerskisalon.veleri.model;

public enum Status {
	PENDING, COMPLETED, CANCELLED
}
