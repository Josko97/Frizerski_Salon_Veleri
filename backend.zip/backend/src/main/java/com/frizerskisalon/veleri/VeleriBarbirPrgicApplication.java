package com.frizerskisalon.veleri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeleriBarbirPrgicApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeleriBarbirPrgicApplication.class, args);
	}

}
