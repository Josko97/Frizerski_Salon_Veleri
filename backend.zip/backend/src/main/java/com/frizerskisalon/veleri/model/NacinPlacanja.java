package com.frizerskisalon.veleri.model;

public enum NacinPlacanja {
	KREDITNA_KARTICA, DEBITNA_KARTICA, GOTOVINA, BODOVI
}
